# Life in Lomé City — 2.5D Prototype

A lightweight Godot 4 project with a tilted third-person camera and actual 3D meshes for the player, buildings, trees, road and cars. All prototype assets are generated in code; no asset downloads are required.

## Open on Android
1. Extract this ZIP into a folder named `LifeInLomeCity`.
2. Open Godot Editor.
3. Choose **Import** or **Scan** and select the `project.godot` file inside the extracted folder.
4. Open the project, then press the Play triangle at the top-right. If asked to choose a main scene, select `scenes/Main.tscn`.
5. Use the on-screen arrows to walk. On a keyboard, use WASD or arrow keys.

## Notes
- This is a starter prototype, not a finished commercial game. It uses simple low-poly shapes, not detailed imported character/car models.
- Android editor performance depends on the phone. The project uses Godot's Compatibility renderer for wider device support.
- An installable APK requires an Android export template and Android build/export setup. This ZIP is the complete editable Godot project source, not an APK.
