extends Node3D

# Life in Lome City: lightweight 2.5D-style 3D prototype.
# The scene is built from simple 3D meshes so no external assets are required.

var player: CharacterBody3D
var camera: Camera3D
var speed: float = 5.2
var mobile_input: Vector2 = Vector2.ZERO
var message_label: Label
var day_time: float = 0.0

func _ready() -> void:
    _make_world()
    _make_player()
    _make_camera()
    _make_mobile_ui()

func _process(delta: float) -> void:
    day_time += delta
    if is_instance_valid(camera) and is_instance_valid(player):
        var target: Vector3 = player.global_position + Vector3(0.0, 1.0, 0.0)
        var desired: Vector3 = player.global_position + Vector3(0.0, 10.0, 12.0)
        camera.global_position = camera.global_position.lerp(desired, min(delta * 3.0, 1.0))
        camera.look_at(target, Vector3.UP)

func _physics_process(_delta: float) -> void:
    if not is_instance_valid(player):
        return
    var direction: Vector2 = mobile_input
    if Input.is_action_pressed("move_forward"):
        direction.y -= 1.0
    if Input.is_action_pressed("move_back"):
        direction.y += 1.0
    if Input.is_action_pressed("move_left"):
        direction.x -= 1.0
    if Input.is_action_pressed("move_right"):
        direction.x += 1.0
    direction = direction.limit_length(1.0)
    # Camera-aligned controls: up moves deeper into the street.
    var move_vector: Vector3 = Vector3(direction.x, 0.0, direction.y)
    player.velocity.x = move_vector.x * speed
    player.velocity.z = move_vector.z * speed
    if not player.is_on_floor():
        player.velocity.y -= 22.0 * get_physics_process_delta_time()
    else:
        player.velocity.y = 0.0
    player.move_and_slide()
    if move_vector.length() > 0.1:
        player.rotation.y = atan2(move_vector.x, move_vector.z)

func _make_world() -> void:
    var world_env: WorldEnvironment = WorldEnvironment.new()
    var environment: Environment = Environment.new()
    environment.background_mode = Environment.BG_SKY
    environment.sky = Sky.new()
    environment.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
    environment.ambient_light_color = Color(0.78, 0.82, 0.86)
    environment.ambient_light_energy = 0.7
    world_env.environment = environment
    add_child(world_env)

    var sun: DirectionalLight3D = DirectionalLight3D.new()
    sun.rotation_degrees = Vector3(-52.0, -28.0, 0.0)
    sun.light_energy = 1.25
    add_child(sun)

    _box(self, "Ground", Vector3(0.0, -0.35, 0.0), Vector3(46.0, 0.5, 46.0), Color(0.78, 0.68, 0.48), true)
    # Asphalt road running through the center.
    _box(self, "Main Road", Vector3(0.0, -0.07, 0.0), Vector3(8.0, 0.08, 46.0), Color(0.19, 0.21, 0.23), false)
    _box(self, "Left Pavement", Vector3(-5.0, -0.02, 0.0), Vector3(1.8, 0.12, 46.0), Color(0.63, 0.60, 0.51), false)
    _box(self, "Right Pavement", Vector3(5.0, -0.02, 0.0), Vector3(1.8, 0.12, 46.0), Color(0.63, 0.60, 0.51), false)
    for z in range(-21, 23, 4):
        _box(self, "Road Dash", Vector3(0.0, -0.015, float(z)), Vector3(0.14, 0.025, 1.8), Color(0.96, 0.88, 0.56), false)

    # Low-poly West African street blocks on both sides of the road.
    var building_colors: Array[Color] = [Color(0.87, 0.67, 0.43), Color(0.91, 0.83, 0.66), Color(0.75, 0.43, 0.30), Color(0.70, 0.75, 0.63), Color(0.91, 0.72, 0.48)]
    var idx: int = 0
    for z in range(-18, 20, 9):
        var h: float = 3.5 + float((idx % 3)) * 0.7
        _make_building(Vector3(-10.0, 0.0, float(z)), Vector3(5.0, h, 5.8), building_colors[idx % building_colors.size()], idx)
        _make_building(Vector3(10.0, 0.0, float(z) + 2.0), Vector3(5.0, h + 0.5, 5.8), building_colors[(idx + 2) % building_colors.size()], idx + 1)
        idx += 1
    # Trees and palms as stylized 3D props.
    for z in range(-18, 21, 6):
        _make_tree(Vector3(-6.7, 0.0, float(z)))
        _make_tree(Vector3(6.7, 0.0, float(z) + 2.5))
    # Parked and moving-looking cars, built as real 3D shapes.
    _make_car(Vector3(-2.3, 0.0, -8.0), Color(0.78, 0.16, 0.12), 0.0)
    _make_car(Vector3(2.3, 0.0, 5.0), Color(0.13, 0.36, 0.76), PI)
    _make_car(Vector3(-2.3, 0.0, 15.0), Color(0.91, 0.79, 0.28), 0.0)

func _make_player() -> void:
    player = CharacterBody3D.new()
    player.name = "Player"
    player.position = Vector3(1.4, 0.1, 11.0)
    add_child(player)
    var collider: CollisionShape3D = CollisionShape3D.new()
    var capsule: CapsuleShape3D = CapsuleShape3D.new()
    capsule.radius = 0.38
    capsule.height = 1.75
    collider.shape = capsule
    collider.position.y = 0.88
    player.add_child(collider)
    # Body and head are separate 3D meshes.
    _mesh_box(player, "Shirt", Vector3(0.0, 1.0, 0.0), Vector3(0.62, 0.72, 0.36), Color(0.10, 0.43, 0.78))
    _mesh_sphere(player, "Head", Vector3(0.0, 1.63, 0.0), 0.25, Color(0.43, 0.25, 0.15))
    _mesh_box(player, "Left Leg", Vector3(-0.17, 0.42, 0.0), Vector3(0.20, 0.55, 0.23), Color(0.16, 0.17, 0.20))
    _mesh_box(player, "Right Leg", Vector3(0.17, 0.42, 0.0), Vector3(0.20, 0.55, 0.23), Color(0.16, 0.17, 0.20))

func _make_camera() -> void:
    camera = Camera3D.new()
    camera.name = "FollowCamera"
    camera.position = player.position + Vector3(0.0, 10.0, 12.0)
    camera.fov = 48.0
    camera.current = true
    add_child(camera)
    camera.look_at(player.position + Vector3(0.0, 1.0, 0.0), Vector3.UP)

func _make_building(pos: Vector3, size: Vector3, color: Color, seed_value: int) -> void:
    var root: Node3D = Node3D.new()
    root.position = pos
    add_child(root)
    _box(root, "Building", Vector3(0.0, size.y * 0.5, 0.0), size, color, true)
    _box(root, "Roof", Vector3(0.0, size.y + 0.12, 0.0), Vector3(size.x + 0.25, 0.24, size.z + 0.25), Color(0.36, 0.23, 0.18), false)
    # Front-facing doors and windows.
    _box(root, "Door", Vector3(0.0, 1.0, size.z * 0.5 + 0.015), Vector3(0.85, 1.9, 0.07), Color(0.28, 0.17, 0.10), false)
    for wx in [-1.45, 1.45]:
        _box(root, "Window", Vector3(wx, 2.0, size.z * 0.5 + 0.025), Vector3(0.85, 0.75, 0.06), Color(0.27, 0.63, 0.77), false)
        _box(root, "Window Frame", Vector3(wx, 2.0, size.z * 0.5 + 0.065), Vector3(0.95, 0.09, 0.035), Color(0.94, 0.88, 0.72), false)
    if seed_value % 2 == 0:
        _box(root, "Shop Sign", Vector3(0.0, size.y - 0.55, size.z * 0.5 + 0.04), Vector3(2.5, 0.38, 0.08), Color(0.14, 0.43, 0.31), false)

func _make_tree(pos: Vector3) -> void:
    var tree: Node3D = Node3D.new()
    tree.position = pos
    add_child(tree)
    _mesh_box(tree, "Trunk", Vector3(0.0, 0.85, 0.0), Vector3(0.28, 1.7, 0.28), Color(0.35, 0.22, 0.12))
    _mesh_sphere(tree, "Leaves", Vector3(0.0, 2.25, 0.0), 1.0, Color(0.16, 0.42, 0.20))

func _make_car(pos: Vector3, color: Color, rotation_y: float) -> void:
    var car: Node3D = Node3D.new()
    car.position = pos
    car.rotation.y = rotation_y
    add_child(car)
    _box(car, "Car Body", Vector3(0.0, 0.55, 0.0), Vector3(1.65, 0.55, 3.0), color, false)
    _box(car, "Cabin", Vector3(0.0, 1.0, -0.15), Vector3(1.25, 0.55, 1.45), Color(0.20, 0.30, 0.34), false)
    for x in [-0.86, 0.86]:
        for z in [-0.95, 0.95]:
            var wheel: MeshInstance3D = MeshInstance3D.new()
            var wheel_mesh: CylinderMesh = CylinderMesh.new()
            wheel_mesh.top_radius = 0.27
            wheel_mesh.bottom_radius = 0.27
            wheel_mesh.height = 0.18
            wheel.mesh = wheel_mesh
            wheel.position = Vector3(x, 0.28, z)
            wheel.rotation_degrees.z = 90.0
            wheel.material_override = _material(Color(0.08, 0.08, 0.09))
            car.add_child(wheel)

func _box(parent: Node3D, node_name: String, pos: Vector3, size: Vector3, color: Color, solid: bool) -> void:
    var body: StaticBody3D = StaticBody3D.new() if solid else StaticBody3D.new()
    body.name = node_name
    body.position = pos
    parent.add_child(body)
    var mesh_instance: MeshInstance3D = MeshInstance3D.new()
    var box_mesh: BoxMesh = BoxMesh.new()
    box_mesh.size = size
    mesh_instance.mesh = box_mesh
    mesh_instance.material_override = _material(color)
    body.add_child(mesh_instance)
    if solid:
        var collision: CollisionShape3D = CollisionShape3D.new()
        var shape: BoxShape3D = BoxShape3D.new()
        shape.size = size
        collision.shape = shape
        body.add_child(collision)

func _mesh_box(parent: Node3D, node_name: String, pos: Vector3, size: Vector3, color: Color) -> void:
    var mesh_instance: MeshInstance3D = MeshInstance3D.new()
    mesh_instance.name = node_name
    var box_mesh: BoxMesh = BoxMesh.new()
    box_mesh.size = size
    mesh_instance.mesh = box_mesh
    mesh_instance.position = pos
    mesh_instance.material_override = _material(color)
    parent.add_child(mesh_instance)

func _mesh_sphere(parent: Node3D, node_name: String, pos: Vector3, radius: float, color: Color) -> void:
    var mesh_instance: MeshInstance3D = MeshInstance3D.new()
    mesh_instance.name = node_name
    var sphere_mesh: SphereMesh = SphereMesh.new()
    sphere_mesh.radius = radius
    sphere_mesh.height = radius * 2.0
    mesh_instance.mesh = sphere_mesh
    mesh_instance.position = pos
    mesh_instance.material_override = _material(color)
    parent.add_child(mesh_instance)

func _material(color: Color) -> StandardMaterial3D:
    var mat: StandardMaterial3D = StandardMaterial3D.new()
    mat.albedo_color = color
    mat.roughness = 0.88
    return mat

func _make_mobile_ui() -> void:
    var layer: CanvasLayer = CanvasLayer.new()
    layer.name = "MobileControls"
    add_child(layer)
    var panel: PanelContainer = PanelContainer.new()
    panel.position = Vector2(16.0, 340.0)
    panel.size = Vector2(210.0, 170.0)
    panel.modulate = Color(1.0, 1.0, 1.0, 0.82)
    layer.add_child(panel)
    var grid: GridContainer = GridContainer.new()
    grid.columns = 3
    grid.add_theme_constant_override("h_separation", 6)
    grid.add_theme_constant_override("v_separation", 6)
    panel.add_child(grid)
    _add_move_button(grid, "", Vector2.ZERO)
    _add_move_button(grid, "▲", Vector2(0.0, -1.0))
    _add_move_button(grid, "", Vector2.ZERO)
    _add_move_button(grid, "◀", Vector2(-1.0, 0.0))
    _add_move_button(grid, "▼", Vector2(0.0, 1.0))
    _add_move_button(grid, "▶", Vector2(1.0, 0.0))
    var hint: Label = Label.new()
    hint.text = "LIFE IN LOMÉ CITY  •  Prototype"
    hint.position = Vector2(245.0, 14.0)
    hint.add_theme_font_size_override("font_size", 18)
    layer.add_child(hint)
    var subhint: Label = Label.new()
    subhint.text = "Touch arrows to walk  |  Keyboard: WASD / arrows"
    subhint.position = Vector2(245.0, 40.0)
    subhint.add_theme_font_size_override("font_size", 13)
    layer.add_child(subhint)

func _add_move_button(parent: GridContainer, caption: String, dir: Vector2) -> void:
    var button: Button = Button.new()
    button.text = caption
    button.custom_minimum_size = Vector2(54.0, 44.0)
    button.focus_mode = Control.FOCUS_NONE
    if caption == "":
        button.disabled = true
        button.modulate = Color(1.0, 1.0, 1.0, 0.0)
    else:
        button.button_down.connect(func() -> void: mobile_input = dir)
        button.button_up.connect(func() -> void: mobile_input = Vector2.ZERO)
    parent.add_child(button)
